package org.springframework.samples.mvc.exceptions;

@SuppressWarnings("serial")
public class BusinessException extends Exception {

}
